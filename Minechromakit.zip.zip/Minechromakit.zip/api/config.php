<?php
/* Configuração privada do site e da base de dados. Não partilhes este ficheiro. */
if (isset($_SERVER['SCRIPT_FILENAME']) && realpath((string) $_SERVER['SCRIPT_FILENAME']) === __FILE__) {
    http_response_code(404);
    exit;
}

return array(
    'db_host' => 'sql203.ezyro.com',
    'db_port' => 3306,
    'db_name' => 'ezyro_43380120_Minecraft',
    'db_user' => 'ezyro_43380120',
    'db_pass' => '6280ce681'
    'site_url' => 'https://ccminechromakit.unaux.com/'
);
