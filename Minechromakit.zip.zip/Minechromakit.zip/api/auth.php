<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');

class ApiException extends Exception
{
    public $httpStatus;
    public function __construct(string $message, int $httpStatus)
    {
        parent::__construct($message);
        $this->httpStatus = $httpStatus;
    }
}

function json_response(array $data, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function is_https_request(): bool
{
    return isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== '' && strtolower((string) $_SERVER['HTTPS']) !== 'off';
}

function start_app_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    ini_set('session.use_only_cookies', '1');
    ini_set('session.use_strict_mode', '1');
    session_name('ccmc_session');
    session_set_cookie_params(array(
        'lifetime' => 0,
        'path' => '/',
        'secure' => is_https_request(),
        'httponly' => true,
        'samesite' => 'Lax'
    ));
    if (!session_start()) {
        throw new ApiException('Não foi possível iniciar a sessão no servidor.', 500);
    }
}

function ensure_csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return (string) $_SESSION['csrf_token'];
}

function read_json_body(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return array();
    }
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        throw new ApiException('Pedido inválido.', 400);
    }
    return $data;
}

function require_method(string $expected): void
{
    $actual = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if ($actual !== $expected) {
        header('Allow: ' . $expected);
        throw new ApiException('Método não permitido.', 405);
    }
}

function require_same_origin(): void
{
    $origin = (string) ($_SERVER['HTTP_ORIGIN'] ?? '');
    if ($origin === '') {
        return;
    }
    $parts = parse_url($origin);
    $originHost = is_array($parts) && isset($parts['host']) ? strtolower($parts['host']) : '';
    if (is_array($parts) && isset($parts['port'])) {
        $originHost .= ':' . (int) $parts['port'];
    }
    $requestHost = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
    if ($originHost === '' || $requestHost === '' || !hash_equals($requestHost, $originHost)) {
        throw new ApiException('Origem do pedido inválida.', 403);
    }
    if (is_https_request() && (!is_array($parts) || strtolower((string) ($parts['scheme'] ?? '')) !== 'https')) {
        throw new ApiException('Origem do pedido inválida.', 403);
    }
}

function require_csrf_token(): void
{
    $received = (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    $expected = (string) ($_SESSION['csrf_token'] ?? '');
    if ($received === '' || $expected === '' || !hash_equals($expected, $received)) {
        throw new ApiException('A sessão expirou. Atualiza a página e tenta novamente.', 419);
    }
}

function database(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $config = require __DIR__ . '/config.php';
    foreach (array('db_host', 'db_name', 'db_user', 'db_pass') as $key) {
        if (!isset($config[$key]) || trim((string) $config[$key]) === '' || strpos((string) $config[$key], 'SUBSTITUIR_') !== false) {
            throw new ApiException('Falta configurar a ligação à base de dados em api/config.php.', 503);
        }
    }
    $port = isset($config['db_port']) ? (int) $config['db_port'] : 3306;
    $dsn = 'mysql:host=' . $config['db_host'] . ';port=' . $port . ';dbname=' . $config['db_name'] . ';charset=utf8mb4';
    try {
        $pdo = new PDO($dsn, (string) $config['db_user'], (string) $config['db_pass'], array(
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ));
    } catch (Throwable $error) {
        error_log('ccMineChromakit: falha ao ligar à base de dados.');
        throw new ApiException('Não foi possível ligar à base de dados. Confere os dados em api/config.php e importa database.sql.', 503);
    }
    return $pdo;
}

function remember_cookie_options(int $expires): array
{
    return array(
        'expires' => $expires,
        'path' => '/',
        'secure' => is_https_request(),
        'httponly' => true,
        'samesite' => 'Lax'
    );
}

function clear_remember_cookie(): void
{
    setcookie('ccmc_remember', '', remember_cookie_options(time() - 3600));
    unset($_COOKIE['ccmc_remember']);
}

function parse_remember_cookie()
{
    $raw = (string) ($_COOKIE['ccmc_remember'] ?? '');
    if ($raw === '' || strlen($raw) > 110) {
        return false;
    }
    $parts = explode('.', $raw, 2);
    if (count($parts) !== 2 ||
        !preg_match('/^[a-f0-9]{32}$/', $parts[0]) ||
        !preg_match('/^[a-f0-9]{64}$/', $parts[1])) {
        return false;
    }
    return array('selector' => $parts[0], 'validator' => $parts[1]);
}

function delete_current_remember_token(PDO $pdo): void
{
    $token = parse_remember_cookie();
    if ($token !== false) {
        $stmt = $pdo->prepare('DELETE FROM ccmc_remember_tokens WHERE selector = :selector');
        $stmt->execute(array(':selector' => $token['selector']));
    }
    clear_remember_cookie();
}

function issue_remember_token(PDO $pdo, int $userId): void
{
    delete_current_remember_token($pdo);
    $selector = bin2hex(random_bytes(16));
    $validator = bin2hex(random_bytes(32));
    $expiresTimestamp = time() + (30 * 24 * 60 * 60);
    $stmt = $pdo->prepare(
        'INSERT INTO ccmc_remember_tokens (user_id, selector, validator_hash, expires_at)
         VALUES (:user_id, :selector, :validator_hash, :expires_at)'
    );
    $stmt->execute(array(
        ':user_id' => $userId,
        ':selector' => $selector,
        ':validator_hash' => hash('sha256', $validator),
        ':expires_at' => gmdate('Y-m-d H:i:s', $expiresTimestamp)
    ));
    $value = $selector . '.' . $validator;
    setcookie('ccmc_remember', $value, remember_cookie_options($expiresTimestamp));
    $_COOKIE['ccmc_remember'] = $value;
}

function restore_remembered_session(PDO $pdo): void
{
    if (!empty($_SESSION['user']) || parse_remember_cookie() === false) {
        return;
    }
    $token = parse_remember_cookie();
    $stmt = $pdo->prepare(
        'SELECT t.validator_hash, t.expires_at, u.id, u.email
         FROM ccmc_remember_tokens t
         INNER JOIN ccmc_users u ON u.id = t.user_id
         WHERE t.selector = :selector
         LIMIT 1'
    );
    $stmt->execute(array(':selector' => $token['selector']));
    $row = $stmt->fetch();
    if (!$row || strtotime((string) $row['expires_at'] . ' UTC') <= time()) {
        if ($row) {
            $delete = $pdo->prepare('DELETE FROM ccmc_remember_tokens WHERE selector = :selector');
            $delete->execute(array(':selector' => $token['selector']));
        }
        clear_remember_cookie();
        return;
    }
    if (!hash_equals((string) $row['validator_hash'], hash('sha256', $token['validator']))) {
        clear_remember_cookie();
        return;
    }
    session_regenerate_id(true);
    $_SESSION['user'] = array('id' => (int) $row['id'], 'email' => (string) $row['email']);
}

function complete_login(PDO $pdo, int $userId, string $email, bool $remember): array
{
    session_regenerate_id(true);
    $_SESSION['user'] = array('id' => $userId, 'email' => $email);
    if ($remember) {
        issue_remember_token($pdo, $userId);
    } else {
        delete_current_remember_token($pdo);
    }
    return array(
        'authenticated' => true,
        'user' => array('id' => $userId, 'email' => $email),
        'csrfToken' => ensure_csrf_token()
    );
}

function normalize_email($value): string
{
    $email = strtolower(trim((string) $value));
    if ($email === '' || strlen($email) > 190 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new ApiException('Escreve um endereço de e-mail válido.', 422);
    }
    return $email;
}

function normalize_password($value): string
{
    $password = (string) $value;
    $length = function_exists('mb_strlen') ? mb_strlen($password, 'UTF-8') : strlen($password);
    if ($length < 8) {
        throw new ApiException('A palavra-passe precisa de pelo menos 8 caracteres.', 422);
    }
    if (strlen($password) > 72) {
        throw new ApiException('A palavra-passe pode ter no máximo 72 bytes.', 422);
    }
    return $password;
}

try {
    start_app_session();
    $action = (string) ($_GET['action'] ?? '');

    if ($action === 'session') {
        require_method('GET');
        if (parse_remember_cookie() !== false && empty($_SESSION['user'])) {
            restore_remembered_session(database());
        }
        $user = $_SESSION['user'] ?? null;
        json_response(array(
            'authenticated' => is_array($user) && isset($user['id'], $user['email']),
            'user' => is_array($user) ? $user : null,
            'csrfToken' => ensure_csrf_token()
        ));
    }

    if (!in_array($action, array('register', 'login', 'logout'), true)) {
        throw new ApiException('Ação inválida.', 404);
    }
    require_method('POST');
    require_same_origin();
    $payload = read_json_body();
    require_csrf_token();
    $pdo = database();

    if ($action === 'register') {
        $email = normalize_email($payload['email'] ?? '');
        $password = normalize_password($payload['password'] ?? '');
        $stmt = $pdo->prepare('SELECT id FROM ccmc_users WHERE email = :email LIMIT 1');
        $stmt->execute(array(':email' => $email));
        if ($stmt->fetch()) {
            throw new ApiException('Este e-mail já tem uma conta. Inicia sessão.', 409);
        }
        $hash = password_hash($password, PASSWORD_DEFAULT);
        if ($hash === false) {
            throw new ApiException('Não foi possível proteger a palavra-passe.', 500);
        }
        try {
            $insert = $pdo->prepare('INSERT INTO ccmc_users (email, password_hash) VALUES (:email, :password_hash)');
            $insert->execute(array(':email' => $email, ':password_hash' => $hash));
        } catch (PDOException $error) {
            if ((string) $error->getCode() === '23000') {
                throw new ApiException('Este e-mail já tem uma conta. Inicia sessão.', 409);
            }
            throw $error;
        }
        json_response(complete_login($pdo, (int) $pdo->lastInsertId(), $email, !empty($payload['remember'])));
    }

    if ($action === 'login') {
        $email = normalize_email($payload['email'] ?? '');
        $password = normalize_password($payload['password'] ?? '');
        $stmt = $pdo->prepare('SELECT id, email, password_hash FROM ccmc_users WHERE email = :email LIMIT 1');
        $stmt->execute(array(':email' => $email));
        $user = $stmt->fetch();
        if (!$user || !password_verify($password, (string) $user['password_hash'])) {
            throw new ApiException('E-mail ou palavra-passe incorretos.', 401);
        }
        if (password_needs_rehash((string) $user['password_hash'], PASSWORD_DEFAULT)) {
            $newHash = password_hash($password, PASSWORD_DEFAULT);
            $update = $pdo->prepare('UPDATE ccmc_users SET password_hash = :hash WHERE id = :id');
            $update->execute(array(':hash' => $newHash, ':id' => (int) $user['id']));
        }
        json_response(complete_login($pdo, (int) $user['id'], (string) $user['email'], !empty($payload['remember'])));
    }

    if ($action === 'logout') {
        delete_current_remember_token($pdo);
        $_SESSION = array();
        session_regenerate_id(true);
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        json_response(array('authenticated' => false, 'csrfToken' => $_SESSION['csrf_token']));
    }
} catch (ApiException $error) {
    json_response(array('message' => $error->getMessage()), $error->httpStatus);
} catch (Throwable $error) {
    error_log('ccMineChromakit auth error: ' . $error->getMessage());
    json_response(array('message' => 'O servidor encontrou um erro. Confere a configuração PHP/MySQL do alojamento.'), 500);
}
